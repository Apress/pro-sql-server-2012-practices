--Listing 10.1. Query to view system memory configuration. 
SELECT total_physical_memory_kb, 
	available_physical_memory_kb, 
	system_memory_state_desc
FROM sys.dm_os_sys_memory; 

--Listing 10.2. Query to see CPU time used by session. 
SELECT ER.session_id, 
	ER.request_id, 
	ES.host_name, 
	ES.login_name, 
	DB_NAME(ER.database_id) AS dbname, 
	ER.start_time, 
	GETDATE() as currenttime, 
	ER.cpu_time, 
	ER.total_elapsed_time, 
	EST.text as query_text
FROM sys.dm_exec_requests ER 
	INNER JOIN sys.dm_exec_sessions ES on ER.session_id = ES.session_id 
	OUTER APPLY sys.dm_exec_sql_text(ER.sql_handle) EST  
	OUTER APPLY sys.dm_exec_query_plan(ER.plan_handle) EQP 
ORDER BY ER.cpu_time DESC; 

--Listing 10.3. Query to view sessions sorted by reads. 
SELECT ER.session_id, 	
	ER.request_id, 
	ES.host_name, 
	ES.login_name, 
	DB_NAME(ER.database_id) AS dbname, 
	ER.start_time, 
	GETDATE() as currenttime, 
	ER.total_elapsed_time, 
	ER.reads, 
	ER.writes, 
	EST.text as query_text
FROM sys.dm_exec_requests ER 
	INNER JOIN sys.dm_exec_sessions ES on ER.session_id = ES.session_id 
	OUTER APPLY sys.dm_exec_sql_text(ER.sql_handle) EST  
	OUTER APPLY sys.dm_exec_query_plan(ER.plan_handle) EQP 
ORDER BY ER.reads DESC;

--Listing 10-4. Creating the DBAInfo database. 
CREATE DATABASE DBAInfo; 

--Listing 10-5. Creating tables to hold monitoring information. 
CREATE TABLE MemoryDMVHistory 
(total_physical_memory_kb BIGINT, 
	available_physical_memory_kb BIGINT, 
	system_memory_state_desc NVARCHAR(256), 
	collection_date_time DATETIME);

CREATE TABLE ProcessorDMVHistory 
(session_id SMALLINT, 
	request_id INT, 
	host_name NVARCHAR(128), 
	login_name NVARCHAR(128), 
	db_name NVARCHAR(128), 
	start_time DATETIME, 
	currenttime DATETIME, 
	cpu_time INT, 
	total_elapsed_time INT, 
	query_text NVARCHAR(MAX), 
	collection_date_time DATETIME);

CREATE TABLE DiskDMVHistory 
(session_id SMALLINT, 
	request_id INT, 
	host_name NVARCHAR(128), 
	login_name NVARCHAR(128), 
	db_name NVARCHAR(128), 
	start_time DATETIME, 
	currenttime DATETIME, 
	total_elapsed_time INT, 
	reads BIGINT, 
	writes BIGINT, 
	query_text NVARCHAR(MAX), 
	collection_date_time DATETIME);

--Listing 10-6. Query to insert the results of the DMV queries into tables. 
INSERT INTO MemoryDMVHistory 
SELECT total_physical_memory_kb, 
	available_physical_memory_kb, 
	system_memory_state_desc, 
	GETDATE() 
FROM sys.dm_os_sys_memory; 

INSERT INTO ProcessorDMVHistory 
SELECT ER.session_id, 
	ER.request_id, 
	ES.host_name, 
	ES.login_name, 
	DB_NAME(ER.database_id) AS dbname, 
	ER.start_time, 
	GETDATE() as currenttime, 
	ER.cpu_time, 
	ER.total_elapsed_time, 
	EST.text as query_text, 
	GETDATE() 
FROM sys.dm_exec_requests ER 
	INNER JOIN sys.dm_exec_sessions ES on ER.session_id = ES.session_id 
	OUTER APPLY sys.dm_exec_sql_text(ER.sql_handle) EST  
	OUTER APPLY sys.dm_exec_query_plan(ER.plan_handle) EQP; 

INSERT INTO DiskDMVHistory 
SELECT ER.session_id, 
	ER.request_id, 
	ES.host_name, 
	ES.login_name, 
	DB_NAME(ER.database_id) AS dbname, 
	ER.start_time, 
	GETDATE() as currenttime, 
	ER.total_elapsed_time, 
	ER.reads, 
	ER.writes, 
	EST.text as query_text, 
	GETDATE() 
FROM sys.dm_exec_requests ER 
	INNER JOIN sys.dm_exec_sessions ES on ER.session_id = ES.session_id 
	OUTER APPLY sys.dm_exec_sql_text(ER.sql_handle) EST  
	OUTER APPLY sys.dm_exec_query_plan(ER.plan_handle) EQP; 
